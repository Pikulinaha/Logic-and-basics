﻿using System;

namespace Lab1
{

    public struct Student
    {
        public string Famil;
        public string Name;
        public string Facult;
        public int Nomzach;
    }

    class Program
    {

        static void Task1()
        {
            Console.WriteLine("=== Задание 1: Разница между max и min элементами массива ===");

            int[] a = { 5, 2, 9, 1, 7, 3, 8, 4, 6, 0 };
            int min = a[0], max = a[0];

            for (int i = 1; i < 10; i++)
            {
                if (a[i] < min) min = a[i];
                if (a[i] > max) max = a[i];
            }

            Console.Write("Массив: ");
            foreach (int num in a) Console.Write(num + " ");
            Console.WriteLine($"\nMin = {min}, Max = {max}, Разница = {max - min}\n");
        }

        static void Task2()
        {
            Console.WriteLine("=== Задание 2: Массив случайных чисел ===");

            Random rand = new Random();
            int[] a = new int[10];

            Console.Write("Случайные числа от 0 до 99: ");
            for (int i = 0; i < 10; i++)
            {
                a[i] = rand.Next(100);
                Console.Write(a[i] + " ");
            }
            Console.WriteLine("\n");
        }

        static void Task3()
        {
            Console.WriteLine("=== Задание 3: Динамический двумерный симметричный массив ===");

            Console.Write("Введите размер массива (квадратная матрица): ");
            if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
            {
                int[,] matrix = new int[n, n];
                Random rand = new Random();
                int centerValue = 0;
                if (n % 2 != 0)
                {
                    centerValue = rand.Next(-20, 21);
                }
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < (n + 1) / 2; j++)
                    {
                        if (n % 2 != 0 && j == n / 2)
                        {
                            matrix[i, j] = centerValue;
                            matrix[i, n - 1 - j] = centerValue;
                        }
                        else
                        {
                            int value = rand.Next(-20, 21); 
                            matrix[i, j] = value;
                            matrix[i, n - 1 - j] = value;
                        }
                    }
                }

                Console.WriteLine($"\nСимметричная матрица {n}x{n} (вертикальная ориентация):");
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        Console.Write($"{matrix[i, j],4} ");
                    }
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Некорректный ввод!\n");
            }
        }

        static void Task4()
        {
            Console.WriteLine("=== Задание 4: Сумма по столбцам матрицы ===");

            int[,] matrix = {
                {1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 11, 12}
            };

            Console.WriteLine("Матрица 3x4:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write($"{matrix[i, j],3} ");
                }
                Console.WriteLine();
            }

            Console.Write("Суммы по столбцам: ");
            for (int j = 0; j < 4; j++)
            {
                int sum = 0;
                for (int i = 0; i < 3; i++)
                {
                    sum += matrix[i, j];
                }
                Console.Write(sum + " ");
            }
            Console.WriteLine("\n");
        }

        static void Task5()
        {
            Console.WriteLine("=== Задание 5: Поиск студента ===");

            Student[] stud = {
                new Student { Famil = "Иванов", Name = "Иван", Facult = "ИТ", Nomzach = 12345 },
                new Student { Famil = "Петров", Name = "Петр", Facult = "Физика", Nomzach = 23456 },
                new Student { Famil = "Сидоров", Name = "Алексей", Facult = "Математика", Nomzach = 34567 }
            };

            Console.WriteLine("Список студентов:");
            for (int i = 0; i < stud.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {stud[i].Famil} {stud[i].Name}, {stud[i].Facult}, №{stud[i].Nomzach}");
            }

            Console.Write("\nВведите фамилию для поиска: ");
            string searchFamil = Console.ReadLine();

            bool found = false;
            foreach (Student student in stud)
            {
                if (student.Famil.Equals(searchFamil, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Найден: {student.Famil} {student.Name}, {student.Facult}, №{student.Nomzach}");
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                Console.WriteLine($"Студент с фамилией '{searchFamil}' не найден.");
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            Task1();
            Task2();
            Task3();
            Task4();
            Task5();

            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}
